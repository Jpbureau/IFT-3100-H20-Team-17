Pour �x�cuter la version pr�compil�e de notre application, lancez:
IFT3100H20_TP1_E17\bin\IFT-3100-H20-Team-17.exe

Notre vid�o de d�monstration est disponbile sur:
https://www.youtube.com/watch?v=1DrBLOcsmLY